#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>

//Initialize the extended RAM
void init_SRAM(void)
{
	MCUCR = (1<<SRE)|(1<<SRW10);
	EMCUCR = (1<<SRW00); 
	SFIOR = (1<<XMM2);
}

//Function to test the extended RAM. Will print out Error!!! in the terminal
//if the content of the RAM is different from what it should be.
void SRAM_test(void)
{
	unsigned char *ram_address = (unsigned char *) 0x1000;

	printf("Starting...\n");

	int i;
	for(i=0;i<0x7FF;i++)
	{
		ram_address[i] = 0x83;
		_delay_ms(2);
	}

	for(i=0;i<0x7FF;i++)
	{
		if(ram_address[i] != 0x83)
		{
			printf("Error!!! RAM no. %d\n",i);
		}
		_delay_ms(2);
	}

	printf("Finished!!!\n");
}
