#include <stdio.h>
#include "settings.h"
#include "uart.h"
#include <avr/interrupt.h>


#include <avr/io.h>
#include <util/delay.h>


void main(void) {
	
	init_UART(BAUD);

	//TEST AREA



/*
	while (1){
		char word[20] = "hallo\n";
		printf(word);
	}
	*/



//init_SRAM();


	//SRAM_test();

	unsigned char *ram_address = (unsigned char *) 0x1000;
	
	printf("Starting test...\n");
	
	for(int i=0;i<0x7FF;i++)
	{
		ram_address[i] = 0x83;
		printf((char)i);
		if (i == 0x7F0)
		{
			i =0;
		}
		_delay_ms(500);

	}
	
}
